
let array = []
console.log(array) // vuoto

array.push('Mela')
array.push('Kiwi')
array.push('Banama')

console.log(array) // pieno

for (let i = 0; i < array.length; i++) {
    console.log(i)
    console.log(array[i])
}